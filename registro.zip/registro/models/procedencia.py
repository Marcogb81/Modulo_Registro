# -*- coding: utf-8 -*-
# importamos modulos
from openerp import models, fields, api
from openerp.osv import  osv
from openerp.exceptions import except_orm
# Clase declara el modelo de la base de datos del modulo para construirlo al instalarse
class registro(models.Model):
    """Éste módulo de python esta subsumido dentro del módulo de Odoo 8 de Registro de pacientes
       y es complementario con su tabla de procedencia de pacientes. Hereda como clave el ide de
       registro.pacientes, y a partir de ahí desarrolla el resto de su tabla propia: procedencia.paciente .
       """
    # llamo al modelo
    _name = 'procedencia.paciente'
    #  este modelo tiene su propia tabla pero hereda el indice de registro de pacientes
    # Aquí empieza la tabla de procedencia.paciente
    procedencia_id = fields.Many2one('registro.paciente')
    proceder = fields.Integer(string ='Número de Historial', store = True, related = "procedencia_id")
    #paciente_id = fields.many2one('registro.paciente', 'Número de Historial', required=True, )
    particular = fields.Boolean(string = 'Particular')
    mutuas = fields.Char(string ='Mutuas',size = 60)
    aseguradoras = fields.Char(string = 'Aseguradoras',size = 60)
    hospitales = fields.Char(string = 'Hospitales', size = 100)
    fundacion = fields.Char(string = 'Fundacion', size = 100)
    fec_ini_trat_hosp = fields.Date(string = 'Inicio tratamiento')
    fec_fin_trat_hosp = fields.Date(string = 'Fin tratamiento')
    carta_pago = fields.Boolean(string = 'Carta de pago')

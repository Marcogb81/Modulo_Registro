# -*- coding: utf-8 -*-
# importamos modulos
from openerp import models, fields, api
from openerp.osv import osv
# genera id de usuario a exportar
class res_partner(osv.osv):
    # llamo al modelo
    _name = 'res.partner'
    _inherit = 'res.partner'

    is_paciente = fields.Boolean('Paciente')
    _defaults = {
        'active': True,
        'is_paciente': False,
    }

# -*- coding: utf-8 -*-
# importamos modulos
from openerp import models, fields, api
from openerp.exceptions import except_orm
import math
import re
import os
# Clase declara el modelo de la base de datos del modulo para construirlo al instalarse
class registro(models.Model):
    # llamo al modelo
    _name = 'registro.paciente'
    # aqui van las funciones y campos
    # Declaro el ID de la tabla del modulo en python para que SQL pueda darlo como primary key
    id = fields.Integer('Numero de ingreso', readonly=True)
    # bloque 1: datos paciente
    Nombre = fields.Char(string='Nombre', size=60, required=True)
    Apellidos = fields.Char(string='Apellidos', size=60, required=True)
    Nif = fields.Char(string='NIF', size=10, required=True)
    Fecha_Nacimiento = fields.Date(string='Fecha de nacimiento', required=True)
    Direccion_Paciente = fields.Char(string='Dirección del paciente', size=100, required=True)
    Poblacion_Paciente = fields.Char(string='Población del paciente', size=60, required=True)
    # Provincia_Paciente = fields.Char(string='Provincia del paciente', size=60 ,required=True)
    Provincia_Paciente = fields.Selection(selection=(
    ('01', 'Álava'), ('02', 'Albacete'), ('03', 'Alicante'), ('04', 'Almería'), ('05', 'Ávila'), ('06', 'Badajoz'),
    ('07', 'Islas Baleares'), ('08', 'Barcelona'), ('09', 'Burgos'), ('10', 'Cáceres'), ('11', 'Cádiz'),
    ('12', 'Castellón'), ('13', 'Ciudad Real'), ('14', 'Córdoba'), ('15', 'La Coruña'), ('16', 'Cuenca'),
    ('17', 'Gerona'), ('18', 'Granada'), ('19', 'Guadalajara'), ('20', 'Guipúzcoa'), ('21', 'Huelva'), ('22', 'Huesca'),
    ('23', 'Jaén'), ('24', 'León'), ('25', 'Lérida'), ('26', 'La Rioja'), ('27', 'Lugo'), ('28', 'Madrid'),
    ('29', 'Malaga'), ('30', 'Murcia'), ('31', 'Navarra'), ('32', 'Orense'), ('33', 'Astirias'), ('34', 'Palencia'),
    ('35', 'Las Palmas'), ('36', 'Pontevedra'), ('37', 'Salamanca'), ('38', 'Santa Cruz de Tenerife'),
    ('39', 'Cantabria'), ('40', 'Segovia'), ('41', 'Sevilla'), ('42', 'Soria'), ('43', 'Tarragona'), ('44', 'Teruel'),
    ('45', 'Toledo'), ('46', 'Valencia'), ('47', 'Valladolid'), ('48', 'Vizcaya'), ('49', 'Zamora'), ('50', 'Zaragoza'),
    ('51', 'Ceuta'), ('52', 'Melilla')), string='Provincia del paciente')
    # en el archivo XML este bloque se divide en dos
    CP_Paciente = fields.Char(string='CP del paciente', size=6, required=True)
    Telefono1_Paciente = fields.Char(string='Telefono fijo paciente', size=9, required=True)
    Telefono2_Paciente = fields.Char(string='Telefono movil paciente', size=9, required=True)
    Email2_Paciente = fields.Char(string='Email del paciente', size=60, required=True)
    Paciente_Activo = fields.Boolean(string='Paciente activo')
    Capacitado_Legalmente = fields.Boolean(string='Capacitado legalmente')
    Fecha_Contacto = fields.Date(string='Fecha de contacto', required=True)
    Fecha_Actualizacion = fields.Date(string='Fecha de actualización')
    # Aquí va datos tabla de tutores y titulares
    Nombre_Tutor_Legal = fields.Char(string='Nombre del tutor', size=60)
    Apellido_Tutor_Legal = fields.Char(string='Apellido del tutor', size=60)
    Nif_Tutor_Legal = fields.Char(string='NIF del tutor', size=30)
    Direccion = fields.Char(string='Dirección del tutor', size=100)
    Poblacion = fields.Char(string='Población del tutor', size=60)
    Provincia = fields.Char(string='Provincia del tutor', size=60)
    CP = fields.Char(string='Código postal', size=6)
    Titular_Telefono1 = fields.Char(string='Telefono fijo tutor', size=9)
    Titular_Telefono2 = fields.Char(string='Telefono movil tutor', size=9)
    Titular_Email1 = fields.Char(string='Email titular 1', size=60)
    Titular_Email2 = fields.Char(string='Email titular 2', size=60)
    # datos de los familiares
    Nif_Padre = fields.Char(string='NIF del padre', size=30)
    Nif_Madre = fields.Char(string='NIF del madre', size=30)
    Mail1 = fields.Char(string='email 1', size=60)
    Mail2 = fields.Char(string='email 2', size=60)
    Telefono1 = fields.Char(string='Telefono fijo', size=9)
    Telefono2 = fields.Char(string='Telefono movil', size=9)
    # campos descriptivos
    Tipo_Lesion = fields.Text(string='Tipo de lesión', size=150, required=True)
    Conocenos = fields.Text(string='Conocenos', size=60)

    # # función que opera con el ingreso de dni y le agrega la letra automaticamente
    @api.onchange('Nif')
    def letraDNI(self):
        # patron = re.compile('[.*|a-zA-Z]')
        numero = self.Nif
        if numero and len(numero) > 6 and len(numero) < 9 and numero.isdigit() or numero == False:
            letras = "TRWAGMYFPDXBNJZSQVHLCKE"
            letra = letras[int(numero) % 23]
            resuelto = str(numero) + '-' + letra
            self.Nif = resuelto
        else:
            warning = {'title': "Advertencia!",
                       'message': "Por favor, introduzca corractamente la parte numérica del DNI y pulse Enter o Tabulador."}
            return {'warning': warning}

    # busca código postal.
    @api.onchange('Provincia_Paciente')
    def onchange_provincia_paciente(self):
        self.CP_Paciente = self.Provincia_Paciente
# -*- coding: utf-8 -*-
# Dentro de la carpeta models guardamos todos los modelos del módulo.
# Lo delcaramos dentro de este init dentro de la carpeta models.
import registro
import procedencia
import res_partner
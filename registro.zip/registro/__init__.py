# -*- coding: utf-8 -*-
# Así importamos en bloque desde la carpeta models todos los modelos de negocio.
# Y tambien incluimos el módulo de python controllers.
import models
import controllers